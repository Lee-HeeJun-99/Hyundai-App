# FitRoute — Vehicle Constraint Navigator (Phase 0/1)

2026 현대자동차그룹 차량용 앱 개발 공모전 준비용 Android/Kotlin 초기 프로젝트입니다.

## 현재 구현된 것

- 일반 Android/AAOS에서 실행 가능한 수동입력 기반 UI (개발 시작용)
- 사용 가능 배터리 용량, 이동거리, 예상 소비량으로 **도착 SoC 범위** 계산 (소비량 ±15%는 시연 가정치)
- 전기차 선적 SoC 상한 / 하선 후 배터리 하한 / 차량 높이 / 도착시간의 제약 평가
- PASS / FAIL / UNKNOWN 3값 판단 (모르는 상태를 성공 처리하지 않음)
- 씨월드고속훼리 공개 규정에 근거한 **데모용** 일반 높이 기준과 산타모니카호 기준
- 독립 Kotlin 코어 테스트 10개

## 현재 구현되지 않은 것

- Pleos Vehicle SDK의 실제 값 수신 (어댑터 인터페이스만 존재)
- NaviHelper 경로 조회 및 실제 ETA
- 실시간 선사 규정 동기화 / 선적 승인
- 실제 배터리 주행 모델을 이용한 예측 오차 보정
- 공식 Pleos Emulator에서 설치·실행 검증

## 빠른 시작

1. Android Studio에서 `VehicleConstraintNavigator` 폴더를 **Open**.
2. JDK 17, Android SDK 35 및 Android Gradle Plugin 다운로드 환경을 준비.
3. `app` 모듈을 Sync/Build.
4. API 28 이상 Android Emulator 또는 Pleos Connect Emulator에 앱을 실행.
5. '현재 모든 입력은 수동/데모 데이터' 메시지를 확인한 뒤 값을 변경해 제약 검사를 수행.

명령행에서 테스트 가능 (Kotlin compiler 필요):

```bash
bash core-tests/run.sh
```

이 패키지에는 Gradle wrapper 바이너리가 포함되어 있지 않습니다. Android Studio에서 Gradle Sync 후 빌드하세요. 이 생성 환경에는 Android SDK/Gradle 실행 환경이 없어 Android APK 빌드가 검증되지 않았습니다.

## 실제 Pleos 연동 절차

1. `app/build.gradle.kts`의 Vehicle SDK 의존성 `ai.pleos.playground:Vehicle:2.3.2` 추가 및 Sync.
2. 공식 EvBattery API 문서에서 `getEvBatteryStateOfCharge`의 **정확한 시그니처**, Capability, 권한, 콜백 타입 확인.
3. AndroidManifest에 해당 API의 공식 permission 선언.
4. `VehicleStateProvider`를 구현하는 `PleosVehicleProvider`를 실제 SDK 버전으로 연결. 비동기 콜백에서 오류/권한 거부를 UNKNOWN으로 처리.
5. Pleos Virtual Console에서 SoC 변경 → `adb logcat`으로 콜백 확인 → 화면에 출처 `PLEOS_SDK` 표기.
6. `NaviHelper:3.0.5`는 이후 단계에서 추가; 실제 경로·ETA 응답 필드 확인 후 연결.

SDK가 지원하지 않는 값을 자동 수신했다고 표시하면 안 됩니다.

## 출처

- SDK 설정: https://document.pleos.ai/docs/pleos-only/connect-sdk-pleos/Vehicle/project-setup
- SDK 진입점: https://document.pleos.ai/docs/pleos-only/connect-sdk-pleos/Vehicle/obtain-domain-object
- SoC: https://document.pleos.ai/docs/pleos-only/vehicle-app-developer-guide/vehicle-app-faq
- 여객선 공개 규정: https://seaferry.co.kr/bbs/content.php?co_id=p1007

**중요:** 모든 규정은 공식 선사 공지를 출발 전에 다시 확인해야 합니다. 선적 허가 또는 배터리 안전을 보증하지 않습니다.
