package com.fitroute.vcn

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import com.fitroute.vcn.core.*
import com.fitroute.vcn.data.RuleCatalog

/** Automotive-friendly first vertical slice. Manual values are clearly labelled. */
class MainActivity : Activity() {
    private lateinit var container: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,24,28,28) }
        scroll.addView(container)
        setContentView(scroll)
        titleText("FitRoute", 28)
        description("Vehicle Constraint Navigator | 오프라인 계산 MVP")
        description("현재 모든 입력은 수동/데모 데이터입니다. Pleos 실제 차량 연동은 아직 활성화되지 않았습니다.")
        val ferry = Spinner(this)
        ferry.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, RuleCatalog.all.map { it.name })
        container.addView(ferry)
        titleText("차량 정보", 20)
        val soc = field("현재 SoC (%)", "65")
        val capacity = field("사용 가능 배터리 용량 (kWh)", "72")
        val height = field("차량 실제 높이 (m, 장착물 포함)", "1.65")
        titleText("이동 계획", 20)
        val distance = field("항구까지 남은 거리 (km)", "150")
        val consumption = field("평균 전비 소비량 (kWh/100km)", "18")
        val minimum = field("하선 후 필요 최소 SoC (%)", "25")
        val arrival = field("출항 몇 분 전 도착 예정?", "90")
        val required = field("선사에서 요구한 출항 전 도착시간 (분)", "")
        description("선사별 지정 도착시간은 공식 예약 안내를 확인해 직접 입력하세요. 미입력 시 시간 조건은 '확인 필요'로 판정합니다.")
        val button = Button(this).apply { text="조건 검사 실행"; textSize=18f; minHeight=64 }
        container.addView(button)
        val output = TextView(this).apply { textSize=17f; setPadding(0,16,0,16) }
        container.addView(output)
        button.setOnClickListener {
            val v = VehicleState(soc.number(), capacity.number(), height.number(), "MANUAL")
            val p = TravelPlan(distance.number(), consumption.number(), 0.15, minimum.number(), arrival.intNumber(), required.intNumber())
            val rule = RuleCatalog.all[ferry.selectedItemPosition]
            val result = ConstraintEngine.evaluate(v,rule,p)
            output.text = buildString {
                append("종합 판정: ${label(result.status)}\n")
                append("(수동/데모 데이터, 선적 승인이 아님)\n\n")
                result.checks.forEach { append("${symbol(it.status)} ${it.name}: ${label(it.status)}\n${it.detail}\n\n") }
                append("규정 확인: ${rule.sourceUrl}\n")
                append("현장 안전 상태·손상·최신 규정 및 승선 승인 여부는 선사에서 최종 판단합니다.")
            }
            output.setTextColor(when(result.status){ Status.PASS->Color.rgb(14,112,75); Status.FAIL->Color.rgb(165,47,47); Status.UNKNOWN->Color.rgb(149,101,0) })
        }
        button.performClick()
    }
    private fun titleText(s:String,size:Int) { container.addView(TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(Color.rgb(20,29,39)); setPadding(0,14,0,8) }) }
    private fun description(s:String) { container.addView(TextView(this).apply { text=s; textSize=14f; setPadding(0,2,0,12) }) }
    private fun field(label:String, sample:String): EditText {
        container.addView(TextView(this).apply { text=label; textSize=15f })
        return EditText(this).also { edit ->
            edit.setSingleLine(true); edit.setText(sample); edit.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            edit.layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
            container.addView(edit)
        }
    }
    private fun EditText.number(): Double? = text.toString().trim().toDoubleOrNull()
    private fun EditText.intNumber(): Int? = text.toString().trim().toIntOrNull()
    private fun label(s:Status) = when(s){Status.PASS->"충족";Status.FAIL->"충돌";Status.UNKNOWN->"확인 필요"}
    private fun symbol(s:Status) = when(s){Status.PASS->"✓";Status.FAIL->"✕";Status.UNKNOWN->"?"}
}
