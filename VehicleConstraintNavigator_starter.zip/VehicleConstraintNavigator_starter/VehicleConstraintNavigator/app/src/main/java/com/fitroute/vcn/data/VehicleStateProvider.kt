package com.fitroute.vcn.data

import com.fitroute.vcn.core.VehicleState

interface VehicleStateProvider {
    fun readSnapshot(onResult: (Result<VehicleState>) -> Unit)
}

/** Default mode for first build: never label these values as SDK readings. */
class ManualVehicleProvider(private val snapshot: () -> VehicleState) : VehicleStateProvider {
    override fun readSnapshot(onResult: (Result<VehicleState>) -> Unit) = onResult(Result.success(snapshot().copy(source = "MANUAL")))
}

/** Explicit integration seam for a future Pleos EvBattery / CarInfo adapter.
 * Implementation must verify the actual SDK signatures, capabilities, permissions and asynchronous callbacks.
 * Do NOT silently fall back to manual data while displaying a live-vehicle badge.
 */
class PleosVehicleProvider : VehicleStateProvider {
    override fun readSnapshot(onResult: (Result<VehicleState>) -> Unit) =
        onResult(Result.failure(UnsupportedOperationException("Pleos SDK 연결 전: 실제 API 콜백 검증 필요")))
}
