package com.fitroute.vcn.data

import com.fitroute.vcn.core.FerryRule

/** Demonstration data. Always verify the current rule and vessel before travel. */
object RuleCatalog {
    private const val source = "https://seaferry.co.kr/bbs/content.php?co_id=p1007"
    val sampleStandard = FerryRule("씨월드고속훼리: 일반 높이 기준 (데모)", 50.0, 2.2, source, "2026-11-03 문서 확인")
    val sampleSantaMonica = FerryRule("씨월드고속훼리: 산타모니카호 (데모)", 50.0, 2.9, source, "2026-11-03 문서 확인")
    val all = listOf(sampleStandard, sampleSantaMonica)
}
