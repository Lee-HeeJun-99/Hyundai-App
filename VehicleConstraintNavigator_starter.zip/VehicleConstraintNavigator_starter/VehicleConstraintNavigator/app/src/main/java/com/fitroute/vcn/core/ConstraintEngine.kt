package com.fitroute.vcn.core

/** All percentages are percentage points (0..100); energy in kWh; distance in km. */
data class VehicleState(val socPct: Double?, val capacityKwh: Double?, val heightM: Double?, val source: String = "MANUAL")
data class FerryRule(val name: String, val maxSocPct: Double, val maxHeightM: Double, val sourceUrl: String, val verifiedAt: String)
data class TravelPlan(
    val distanceToPortKm: Double?,
    val consumptionKwhPer100Km: Double?,
    val consumptionVariationFraction: Double = 0.15,
    val minimumPostFerrySocPct: Double?,
    val arrivalMinutesBeforeDeparture: Int?,
    val minimumArrivalMinutesBeforeDeparture: Int?
)
enum class Status { PASS, FAIL, UNKNOWN }
data class Check(val name: String, val status: Status, val detail: String)
data class Assessment(val checks: List<Check>, val arrivalSocRange: ClosedFloatingPointRange<Double>?) {
    // Unknown must never be interpreted as a pass.
    val status: Status get() = when {
        checks.any { it.status == Status.FAIL } -> Status.FAIL
        checks.any { it.status == Status.UNKNOWN } -> Status.UNKNOWN
        else -> Status.PASS
    }
}

object ConstraintEngine {
    fun evaluate(vehicle: VehicleState, rule: FerryRule, plan: TravelPlan): Assessment {
        val checks = mutableListOf<Check>()
        val soc = vehicle.socPct
        val cap = vehicle.capacityKwh
        val km = plan.distanceToPortKm
        val rate = plan.consumptionKwhPer100Km
        val variation = plan.consumptionVariationFraction
        val socRange = if (
            soc != null && cap != null && km != null && rate != null &&
            soc in 0.0..100.0 && cap > 0 && km >= 0 && rate >= 0 && variation in 0.0..1.0
        ) {
            val nominal = km * rate / 100.0 / cap * 100.0
            // Do not clip the theoretical range: a negative prediction is evidence of an impossible energy budget.
            val low = soc - nominal * (1 + variation)
            val high = soc - nominal * (1 - variation)
            low..high
        } else null

        if (socRange == null) {
            checks += Check("선적 시점 배터리", Status.UNKNOWN, "유효한 SoC·용량·거리·소비량이 필요합니다.")
            checks += Check("하선 후 최소 배터리", Status.UNKNOWN, "예상 도착 배터리 정보가 없습니다.")
        } else {
            val high = socRange.endInclusive
            val low = socRange.start
            val limit = rule.maxSocPct
            val upperStatus = when { low > limit -> Status.FAIL; high <= limit -> Status.PASS; else -> Status.UNKNOWN }
            checks += Check("선적 SoC 상한", upperStatus, "항구 도착 예상 ${fmt(low)}~${fmt(high)}%, 제한 ${fmt(limit)}% 이하")
            val minimum = plan.minimumPostFerrySocPct
            val lowerStatus = when {
                minimum == null || minimum !in 0.0..100.0 -> Status.UNKNOWN
                high < minimum || low < 0.0 -> Status.FAIL.takeIf { high < minimum } ?: Status.UNKNOWN
                low >= minimum -> Status.PASS
                else -> Status.UNKNOWN
            }
            checks += Check("하선 후 최소 배터리", lowerStatus, if (minimum == null) "필요 최소 SoC 미입력" else "요구량 ${fmt(minimum)}%, 도착 예상 ${fmt(low)}~${fmt(high)}%")
        }
        val height = vehicle.heightM
        checks += Check("차량 높이", when { height == null || height <= 0 -> Status.UNKNOWN; height > rule.maxHeightM -> Status.FAIL; else -> Status.PASS },
            if (height == null) "차량 높이 미입력" else "차량 ${fmt(height)}m / 선사 제한 ${fmt(rule.maxHeightM)}m")
        val lead = plan.arrivalMinutesBeforeDeparture
        val required = plan.minimumArrivalMinutesBeforeDeparture
        checks += Check("선적 준비시각", when {
            lead == null || required == null || lead < 0 || required < 0 -> Status.UNKNOWN
            lead < required -> Status.FAIL
            else -> Status.PASS
        }, if (lead == null || required == null) "선사별 지정 도착시간을 직접 확인해야 합니다." else "출항 ${lead}분 전 도착 / 요구 ${required}분 전")
        return Assessment(checks, socRange)
    }
    private fun fmt(value: Double): String = "%.1f".format(java.util.Locale.US, value)
}
