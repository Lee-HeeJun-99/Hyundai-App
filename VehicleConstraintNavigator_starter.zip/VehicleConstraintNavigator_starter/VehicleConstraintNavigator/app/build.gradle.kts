plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fitroute.vcn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fitroute.vcn"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Phase 1: intentionally no proprietary SDK dependency in the compilable baseline.
// After verifying access to Pleos Maven and exact EvBattery callback signatures:
// implementation("ai.pleos.playground:Vehicle:2.3.2")
// implementation("ai.pleos.playground:NaviHelper:3.0.5")
