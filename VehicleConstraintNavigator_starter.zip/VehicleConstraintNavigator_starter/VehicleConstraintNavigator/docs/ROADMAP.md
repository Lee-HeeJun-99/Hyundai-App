# Phase 계획

## Phase 0 — 완료(코드/설계)
- [x] 고객 문제와 여객선 기준 시나리오 설정
- [x] 기초 Kotlin 제약 엔진
- [x] 수동 입력 UI
- [x] 시나리오별 UNKNOWN/FAIL/PASS 판정 및 코어 테스트
- [ ] Android Studio에서 APK 실제 빌드

## Phase 1 — Pleos SDK 연결
- [ ] Pleos SDK Maven Sync
- [ ] EvBattery getEvBatteryStateOfCharge 실제 시그니처·권한 확인
- [ ] Vehicle SDK initialize/capability/get/callback 연결
- [ ] Console SOC 변경과 화면 상태 동기화 검증
- [ ] CarInfo 높이 필드 확인, 지원 안 되면 명시적 수동 입력

## Phase 2 — Navi + 사용자 경험
- [ ] NaviHelper 경로·ETA 필드 검증
- [ ] ETA/거리 자동 입력 (지원 안 되면 명시적 수동 모드)
- [ ] 출처/갱신시간/데이터 신선도 UI
- [ ] 제약 충돌 시 실행 가능한 권장안
- [ ] 선사별 규정의 업데이트 날짜/출처 표시

## Phase 3 — 정량 실험 및 제출
- [ ] 배터리 상한/하한 경계 + 차량 높이 + 도착 시각 조합 50개 이상
- [ ] 실제 SDK vs Mock 데이터 분리 시연
- [ ] 반복 실행 중 앱 안정성 확인
- [ ] 기획서 및 시연 영상
