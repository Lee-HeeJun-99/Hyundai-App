import com.fitroute.vcn.core.*

fun check(name: String, actual: Status, expected: Status) {
    kotlin.check(actual == expected) { "$name expected $expected, got $actual" }
    println("PASS: $name = $actual")
}
fun main() {
    val rule = FerryRule("test",50.0,2.2,"https://example.org","demo")
    val good = VehicleState(55.0,72.0,1.7)
    val plan = TravelPlan(100.0,18.0,0.15,20.0,90,60)
    check("all conditions pass",ConstraintEngine.evaluate(good,rule,plan).status,Status.PASS)
    check("too much charge",ConstraintEngine.evaluate(good.copy(socPct=95.0),rule,plan).status,Status.FAIL)
    check("too little charge",ConstraintEngine.evaluate(good.copy(socPct=20.0),rule,plan).status,Status.FAIL)
    check("vehicle too tall",ConstraintEngine.evaluate(good.copy(heightM=2.5),rule,plan).status,Status.FAIL)
    check("late arrival",ConstraintEngine.evaluate(good,rule,plan.copy(arrivalMinutesBeforeDeparture=45)).status,Status.FAIL)
    check("missing condition not approved",ConstraintEngine.evaluate(good,rule,plan.copy(minimumArrivalMinutesBeforeDeparture=null)).status,Status.UNKNOWN)
    check("missing soc",ConstraintEngine.evaluate(good.copy(socPct=null),rule,plan).status,Status.UNKNOWN)
    check("crossing upper boundary",ConstraintEngine.evaluate(good.copy(socPct=76.0),rule,plan).status,Status.UNKNOWN)
    check("invalid battery capacity",ConstraintEngine.evaluate(good.copy(capacityKwh=0.0),rule,plan).status,Status.UNKNOWN)
    check("missing height",ConstraintEngine.evaluate(good.copy(heightM=null),rule,plan).status,Status.UNKNOWN)
    println("All 10 core tests passed.")
}
