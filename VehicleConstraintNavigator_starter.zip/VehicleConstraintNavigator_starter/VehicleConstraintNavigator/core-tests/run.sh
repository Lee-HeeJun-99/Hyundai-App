#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/fitroute-test
kotlinc app/src/main/java/com/fitroute/vcn/core/ConstraintEngine.kt core-tests/ConstraintEngineTest.kt -include-runtime -d /tmp/fitroute-test/test.jar
java -jar /tmp/fitroute-test/test.jar
